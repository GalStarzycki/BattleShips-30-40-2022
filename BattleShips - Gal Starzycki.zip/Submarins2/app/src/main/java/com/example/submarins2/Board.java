package com.example.submarins2;


import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class Board  extends View {
    private Paint paint;
    private Paint bgPaint;
    private Square[][] tileArr;
    int size1=0,size2=0,size3=0,size4=0, countZeroBlock=0;

    public Board(Context context){
        super(context);
        paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        bgPaint = new Paint();
        int x,y;
        x=0;y=0;
//building the board
        paint.setStrokeWidth(12);
        bgPaint.setColor(Color.rgb(255,255,255));
        tileArr= new Square[11][11];
        for (int i = 0; i < 11; i++){
            for (int j= 0; j < 11; j++){
                if(i==0 || j==0)
                    tileArr[i][j]=new Indicator(i*100,j*100,(i*100)+100,(j*100)+100);
                else
                    tileArr[i][j]=new Square(i*100,j*100,(i*100)+100,(j*100)+100);
            }
            x=0;
        }
        //setting up the board-------------------------------------------------------------------------------------------------------------------------------------
        int shipCount=1,shipSize=3;
        boolean hori=false;
        boolean vert=false;
        Random rnd=new Random();
        int i=0, i2= 0;
        int j=0, j2=0;
        int length=shipSize ;
        int lengthBorder =length+2;
        int vOrh= rnd.nextInt(2);
        while(shipCount!=11){
            i= rnd.nextInt((10 - 1) + 1) + 1;
            i2= i;
            j= rnd.nextInt((10 - 1) + 1) + 1;
            j2=j;
            length=shipSize ;
            lengthBorder =length+2;
            vOrh=rnd.nextInt(2);
            //Randomizes vertical and horizontal
            if(vOrh==1){
                hori=true;
            }
            if(vOrh==0){
                vert=true;
            }
            if (hori==true){
                while(i+shipSize>=11){

                    i= rnd.nextInt((10 - 1) + 1) + 1;
                    i2=i;
                }

            }
            if(vert==true ){
                while(j+shipSize>=11){
                    j= rnd.nextInt((10 - 1) + 1) + 1;
                    j2=j;
                }

            }


            if(tileArr[i][j].GetGhost()==false && tileArr[i][j].GetHasShip()==false  ){
                if(hori==true && tileArr[i+shipSize][j].GetGhost()==false && tileArr[i+shipSize][j].GetHasShip()==false  ) {
                    //Builds head of ship
                    tileArr[i][j] = new Ship(i * 100, j * 100, (i * 100) + 100, (j * 100) + 100);
                    tileArr[i][j].SetHasShip(true);
                    //Builds  ship
                    while (length >= 1) {
                        tileArr[i2 + 1][j] = new Ship((i2 + 1) * 100, j * 100, ((i2 + 1) * 100) + 100, (j * 100) + 100);
                        tileArr[i2 + 1][j].SetHasShip(true);
                        i2++;
                        length--;
                    }


                    //finds the ship's borders
                    for (int k = 1; k < lengthBorder; k++) {
                        SetBorders(tileArr, i, j);
                        i++;
                    }

                }
                if(vert==true&& tileArr[i][j+shipSize].GetGhost()==false && tileArr[i][j+shipSize].GetHasShip()==false){
                    //builds head of the ship
                    tileArr[i][j] = new Ship(i * 100, j * 100, (i * 100) + 100, (j * 100) + 100);
                    tileArr[i][j].SetHasShip(true);
                    //builds the rest of the ship
                    while (length >= 1) {
                        tileArr[i][j2 + 1] = new Ship(i * 100, (j2 + 1) * 100, (i2 * 100) + 100, ((j2 + 1) * 100) + 100);
                        tileArr[i][j2 + 1].SetHasShip(true);
                        j2++;

                        length--;
                    }
                    //finds the ship's borders
                    for (int k = 1; k < lengthBorder; k++) {
                        SetBorders(tileArr, i, j);
                        j++;
                    }
                }
                //changes the size
                shipCount++;

                if (shipSize == 3 && (shipCount) == 2)
                    shipSize--;
                if (shipSize == 2 && (shipCount) == 4)
                    shipSize--;
                if (shipSize == 1 && (shipCount) == 7)
                    shipSize--;
            }
            i=0; j=0; i2=0; j2=0;
            hori=false;
            vert=false;

        }
        for (int k = 1; k < 11; k++){
            for (int l= 1; l < 11; l++){
                if(tileArr[k][l] instanceof Ship){
                    if (tileArr[0][l] instanceof Indicator)
                        ((Indicator) tileArr[0][l]).NumShipsUp();
                    if(tileArr[k][0] instanceof Indicator)
                        ((Indicator) tileArr[k][0]).NumShipsUp();
                }
                tileArr[k][l].SetGhost(false);
            }
        }
//----------------------------------------------------------------------------------------------------------------------------------------

    }

    public void SetBorders(Square[][] tileArr, int i, int j){
        for (int k = 1; k < 11; k++){
            for (int l= 1; l < 11; l++){
                if(Math.abs(tileArr[k][l].GetX()-tileArr[i][j].GetX())==100 && Math.abs(tileArr[k][l].GetY()-tileArr[i][j].GetY())==100 && !(tileArr[k][l] instanceof Ship)) {
                    tileArr[k][l].SetGhost(true);
                }
                if(Math.abs(tileArr[k][l].GetY()-tileArr[i][j].GetY())==100 && Math.abs(tileArr[k][l].GetX()-tileArr[i][j].GetX())==0 && !(tileArr[k][l] instanceof Ship)){
                    tileArr[k][l].SetGhost(true);
                }
                if(Math.abs(tileArr[k][l].GetX()-tileArr[i][j].GetX())==100 && Math.abs(tileArr[k][l].GetY()-tileArr[i][j].GetY())==0 && !(tileArr[k][l] instanceof Ship)) {
                    tileArr[k][l].SetGhost(true);
                }

            }

        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(bgPaint);
        if(size1==4 && size2==3 && size3==2 && size4==1 && countZeroBlock==20)   {
            paint.setStrokeWidth(4);
            paint.setTextSize(60);
            canvas.drawText("You Win!",500,500,paint);

        }
        else{
            for (int i = 0; i < 11; i++){
                for (int j= 0; j < 11; j++){
                    tileArr[i][j].Draw(canvas,paint);
                    tileArr[i][j].DrawBorder(canvas,paint);
                }
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeWidth(4);
            paint.setTextSize(60);
            canvas.drawText("Ship Size",0,1200,paint);
            canvas.drawText("1",100,1300,paint);
            canvas.drawText("2",100,1400,paint);
            canvas.drawText("3",100,1500,paint);
            canvas.drawText("4",100,1600,paint);
            canvas.drawText("Found Count",canvas.getWidth()-400,1200,paint);
            canvas.drawText(String.valueOf(size1),canvas.getWidth()-400,1300,paint);
            canvas.drawText(String.valueOf(size2),canvas.getWidth()-400,1400,paint);
            canvas.drawText(String.valueOf(size3),canvas.getWidth()-400,1500,paint);
            canvas.drawText(String.valueOf(size4),canvas.getWidth()-400,1600,paint);
        }

    }
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN){
            int x=(int)event.getX(),y=(int)event.getY();
            for (int k = 1; k < 11; k++){
                for (int l= 1; l < 11; l++) {
                    if(tileArr[k][l].GetX()+100>x && tileArr[k][l].GetX()<x ){
                        if(tileArr[k][l].GetY()+100>y && tileArr[k][l].GetY()<y ){

                            if(tileArr[k][l].GetClicks()==0){
                                tileArr[k][l].SetColor("cyan");
                                tileArr[k][l].PlusClicks();
                                tileArr[k-1][l-1].SetGhost(false);
                                if(k+1!=11 && l+1!=11)
                                tileArr[k+1][l+1].SetGhost(false);
                                if(l+1!=11)
                                tileArr[k-1][l+1].SetGhost(false);
                                if(k+1!=11)
                                tileArr[k+1][l-1].SetGhost(false);
                            }
                            else if(tileArr[k][l].GetClicks()==1){
                                tileArr[k][l].SetColor("black");
                                tileArr[k][l].PlusClicks();
                                tileArr[k-1][l-1].SetGhost(true);
                                if(k+1!=11 && l+1!=11)
                                tileArr[k+1][l+1].SetGhost(true);
                                if(l+1!=11)
                                tileArr[k-1][l+1].SetGhost(true);
                                if(k+1!=11)
                                tileArr[k+1][l-1].SetGhost(true);
                                ((Indicator) tileArr[0][l]).GuessShipsUp();
                                ((Indicator) tileArr[k][0]).GuessShipsUp();
                            }
                            else if(tileArr[k][l].GetClicks()==2){
                                tileArr[k][l].SetColor("white");
                                tileArr[k][l].PlusClicks();
                                tileArr[k-1][l-1].SetGhost(false);
                                if(k+1!=11 && l+1!=11)
                                    tileArr[k+1][l+1].SetGhost(false);
                                if(l+1!=11)
                                    tileArr[k-1][l+1].SetGhost(false);
                                if(k+1!=11)
                                    tileArr[k+1][l-1].SetGhost(false);
                                ((Indicator) tileArr[0][l]).GuessShipsDown();
                                ((Indicator) tileArr[k][0]).GuessShipsDown();
                            }

                        }
                    }
                }
            }
             for (int k = 1; k < 11; k++){
                for (int l= 1; l < 11; l++) {
                    if(tileArr[k][l].GetColor()=="black" && tileArr[k][l].GetGhost()==true){
                        tileArr[k][l].SetColor("red");
                    }
                    if(tileArr[k][l].GetColor()=="red" && tileArr[k][l].GetGhost()==false)
                        tileArr[k][l].SetColor("black");
                }
            }
            int count=0;
            int[] ship=new int[4];
            //counting for ships of 2-4 horizontal
            for (int l = 1; l < 11; l++) {
                for (int k = 1; k < 11; k++) {
                    if (tileArr[k][l].GetColor() == "black") {
                        while (tileArr[k][l].GetColor() == "black") {
                            count++;
                            if(k==10)
                                break;
                            k++;
                        }
                        if (count >= 5) {
                            for (int i=count; i>0;i--){
                                tileArr[k-i][l].SetColor("red");
                            }
                        }
                        if (1 < count && count <= 4)
                          /*  if(count==1 && tileArr[k][l-1].GetColor() != "black" && tileArr[k][l+1].GetColor() != "black")
                                ship[0]+=1;
                            else*/
                            ship[count - 1] += 1;
                        count = 0;
                    }
                    if(tileArr[k][l].GetColor() == "red"){
                        if(k!=10 && tileArr[k+1][l].GetColor() == "black")
                            tileArr[k+1][l].SetColor("red");
                        if(tileArr[k-1][l].GetColor() == "black")
                            tileArr[k-1][l].SetColor("red");
                        if(l!=10 && tileArr[k][l+1].GetColor() == "black")
                            tileArr[k][l+1].SetColor("red");
                        if(tileArr[k][l-1].GetColor() == "black")
                            tileArr[k][l-1].SetColor("red");
                    }
                }
            }
            //counting for ships of 2-4 vertical
            for (int k = 1; k < 11; k++) {
                for (int l = 1; l < 11; l++) {
                    while(tileArr[k][l].GetColor()=="black") {
                        count++;
                        if(l==10)
                            break;
                        l++;

                    }
                    if (count >= 5) {
                        for (int i=count; i>0;i--){
                            tileArr[k][l-i].SetColor("red");
                        }
                    }
                    if(1<count && count<=4)
                     /*   if(count==1 && tileArr[k-1][l].GetColor() != "black"&& tileArr[k+1][l].GetColor() != "black")
                            ship[0]+=1;
                        else*/
                         ship[count-1]+=1;


                    count=0;
                }
            }
            for (int k = 1; k < 11; k++) {
                for (int l = 1; l < 11; l++) {
                    if(tileArr[k][l].GetColor() == "black"){
                        if(k!=10 && l!=10){
                            if(tileArr[k+1][l].GetColor() != "black" && tileArr[k-1][l].GetColor() != "black" &&tileArr[k][l+1].GetColor() != "black" && tileArr[k][l-1].GetColor() != "black"){
                                ship[0]+=1;
                            }
                        }
                        else if(l!=10 && k==10){
                            if(tileArr[k-1][l].GetColor() != "black" &&tileArr[k][l+1].GetColor() != "black" && tileArr[k][l-1].GetColor() != "black"){
                                ship[0]+=1;
                            }
                        }
                        else if(l==10 && k!=10){
                                if(tileArr[k+1][l].GetColor() != "black" && tileArr[k-1][l].GetColor() != "black" && tileArr[k][l-1].GetColor() != "black"){
                                    ship[0]+=1;
                                }
                            }
                        else if(l==10 && k==10){
                                if(tileArr[k-1][l].GetColor() != "black" && tileArr[k][l-1].GetColor() != "black"){
                                    ship[0]+=1;
                                }
                            }

                    }
                }
            }

            size1=ship[0];
            size2=ship[1];
            size3=ship[2];
            size4=ship[3];
             countZeroBlock=0;
                for (int l = 1; l < 11; l++) {
                    if(((Indicator)tileArr[0][l]).GuessEquals()==true){
                        countZeroBlock++;
                    }
                }
                for(int i=1 ; i<11; i++){
                    if(((Indicator)tileArr[i][0]).GuessEquals()==true){
                        countZeroBlock++;
                    }
                }

            invalidate();
        }
        return true;
    }

}
