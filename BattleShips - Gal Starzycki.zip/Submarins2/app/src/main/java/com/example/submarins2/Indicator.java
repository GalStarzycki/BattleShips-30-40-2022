package com.example.submarins2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Indicator extends Square{
    int numShips;
    int guessShips;
    public Indicator( int x, int y, int xEnd,int yEnd){
        super(x,  y,  xEnd, yEnd);
    }
    public void NumShipsUp(){this.numShips++;}
    public void GuessShipsUp(){this.guessShips++;}
    public void GuessShipsDown(){this.guessShips--;}
    public boolean GuessEquals(){if(this.guessShips==this.numShips) return true; return false;}
    @Override
    public void Draw(Canvas canvas, Paint paint){
        Paint paint2= new Paint();
        if(this.guessShips!=this.numShips)
        paint2.setColor(Color.RED);
        else
        paint2.setColor(Color.BLACK);
        paint2.setTextSize(50);  //set text size
        paint2.setTextAlign(Paint.Align.CENTER);
        float textSize = paint2.getTextSize();
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(x,y,xEnd,yEnd,paint);
        canvas.drawText(String.valueOf(numShips),x+50,y+50,paint2);
    }

}
