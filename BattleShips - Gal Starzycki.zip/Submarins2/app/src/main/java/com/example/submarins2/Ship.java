package com.example.submarins2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Ship extends Square{

    public Ship(int x, int y, int xEnd,int yEnd){
        super(x,  y,  xEnd, yEnd);

    }
    @Override
    public void SetColor(String color){this.color=color;}

    @Override
    public int GetClicks(){return this.clicks;}
    @Override
    public void PlusClicks(){
        if(this.clicks>=2)
            this.clicks=0;
        else
            this.clicks++;
    }

    @Override
    public void Draw(Canvas canvas, Paint paint){
        if(this.color=="cyan")
            paint.setColor(Color.CYAN);
        if(this.color=="black")
            paint.setColor(Color.BLACK);
        if(this.color=="white")
            paint.setColor(Color.WHITE);
        if(this.color=="red")
            paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(x,y,xEnd,yEnd,paint);
    }

}
