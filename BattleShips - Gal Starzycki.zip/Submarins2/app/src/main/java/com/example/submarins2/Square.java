package com.example.submarins2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Square {
    int x;
    int y;
    int xEnd;
    int yEnd;
    int clicks;
    boolean ghost;
    boolean hasShip;
    String color;
    public Square(int x, int y,int xEnd,int yEnd){
        this.y=y;
        this.x=x;
        this.xEnd = xEnd;
        this.yEnd = yEnd;
        color="white";
        ghost=false;
        hasShip=false;
        clicks=0;
    }
    public int GetX(){return this.x;}
    public int GetY(){return this.y;}

    public boolean GetHasShip(){return this.hasShip;}
    public void SetHasShip(boolean hasShip){this.hasShip=hasShip;}
    public boolean GetGhost(){return  this.ghost;}
    public void SetGhost(boolean ghost){this.ghost=ghost;}
    public void SetColor(String color){this.color=color;}
    public String GetColor(){return this.color;}
    public int GetClicks(){return this.clicks;}
    public void PlusClicks(){
        if(this.clicks>=2)
            this.clicks=0;
        else
            this.clicks++;
    }
    public void Draw(Canvas canvas,Paint paint){
        //if(ghost==false)
        if(this.color=="cyan"){
            paint.setColor(Color.CYAN);
        }

        if(this.color=="black"){
            paint.setColor(Color.BLACK);

        }
        if(this.color=="white"){
            paint.setColor(Color.WHITE);
        }
        if(this.color=="red")
            paint.setColor(Color.RED);
        /*else
        paint.setColor(Color.RED);*/
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(x,y,xEnd,yEnd,paint);
    }
    public void DrawBorder(Canvas canvas,Paint paint){
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(x,y,xEnd,yEnd,paint);
    }




}